import os
from dotenv import load_dotenv
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.role import Role

load_dotenv()
app = create_app()

with app.app_context():
    try:
        # Create superadmin role if not exists
        role = Role.query.filter_by(name='superadmin').first()
        if not role:
            role = Role(name='superadmin', description='Super Administrator', permissions={'all': True})
            db.session.add(role)
            db.session.commit()
            print('Superadmin role created.')
        else:
            print('Superadmin role already exists.')

        # Create superadmin user if not exists
        username = os.getenv('ADMIN_USERNAME')
        email = os.getenv('ADMIN_EMAIL')
        password = os.getenv('ADMIN_PASSWORD')
        print(f'Using credentials: username={username}, email={email}, password={password}')
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User(username=username, email=email)
            user.set_password(password)
            user.role = role
            db.session.add(user)
            db.session.commit()
            print('Superadmin user created.')
        else:
            print('Superadmin user already exists.')
        print(f'User: {user}')
        print(f'Password hash: {user.password_hash}')
        print(f'Role: {user.role.name if user and user.role else None}')
    except Exception as e:
        print(f'Error during superadmin creation: {e}')


# --- Root-level Health Check Endpoint ---

from flask import Blueprint, make_response

main_bp = Blueprint("main", __name__)

@main_bp.route('/health', methods=['GET'])
def health():
    return make_response({'status': 'ok', 'message': 'Service healthy'}, 200)
from flask import Blueprint, render_template, redirect, request, url_for, session, jsonify
from flask_login import current_user

main_bp = Blueprint("main", __name__)

@main_bp.route('/set_language', methods=['GET'])
def set_language():
    lang = request.args.get('language')
    if lang in ['en', 'tr']:
        session['lang'] = lang
    return redirect(request.referrer or url_for('main.index'))


@main_bp.route("/")
def index():
    # Optional: Redirect authenticated users to their dashboards
    if current_user.is_authenticated:
        if hasattr(current_user, 'is_admin') and callable(current_user.is_admin) and current_user.is_admin():
            return redirect(url_for("admin.admin_dashboard"))
        else:
            return redirect(url_for("client.client_dashboard"))

    return render_template("index.html")  # This is your landing page

# Public payment page for viewing payment details by ID
@main_bp.route('/payment/<int:payment_id>', methods=['GET'])
def payment_page(payment_id: int):
    try:
        from app.models import Payment
        payment = Payment.query.get(payment_id)
    except Exception:
        payment = None
    if not payment:
        # Render a simple 404-ish page to avoid exposing stack traces
        return render_template('error/400.html', title='Payment Not Found'), 404
    return render_template('payment/view.html', payment=payment)

@main_bp.route('/pricing')
def pricing():
    return render_template('pricing.html')

# --- API Blueprint and Heartbeat Endpoint (stub) ---
api_bp = Blueprint('api', __name__, url_prefix='/api')

@api_bp.route('/status/heartbeat')
def status_heartbeat():
    return jsonify({'status': 'ok', 'message': 'API is alive'})

# In your app factory or main __init__, ensure to register api_bp
# app.register_blueprint(api_bp)

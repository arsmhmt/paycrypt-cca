from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_babel import Babel
from flask_caching import Cache

db = SQLAlchemy()
login_manager = LoginManager()
cache = Cache()


babel = Babel()


def get_locale():
    from flask import session
    return session.get('lang', 'en')

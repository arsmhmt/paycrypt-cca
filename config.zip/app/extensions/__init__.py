from .extensions import db, login_manager, cache, babel, get_locale
